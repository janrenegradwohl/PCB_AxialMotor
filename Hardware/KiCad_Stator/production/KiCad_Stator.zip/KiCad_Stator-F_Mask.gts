G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.3*
G04 #@! TF.CreationDate,2026-05-26T00:49:55+02:00*
G04 #@! TF.ProjectId,KiCad_Stator,4b694361-645f-4537-9461-746f722e6b69,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.3) date 2026-05-26 00:49:55*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
